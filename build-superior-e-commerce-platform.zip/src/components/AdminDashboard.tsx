import { useState } from 'react';
import { 
  LayoutDashboard, Package, ShoppingCart, BarChart3, Settings, LogOut, 
  Search, Plus, Edit2, Trash2, X, TrendingUp, DollarSign, PackageCheck, 
  UserCheck, Star, Scissors, ArrowUp 
} from 'lucide-react';
import { Product } from '../types';

interface AdminDashboardProps {
  products: Product[];
  setProducts: (products: Product[]) => void;
  onLogout: () => void;
}

export default function AdminDashboard({ products, setProducts, onLogout }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'products' | 'trimmers' | 'orders' | 'analytics'>('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '',
    price: 0,
    category: 'Saloon Grooming',
    description: '',
    inStock: true,
  });

  const saloonProducts = products.filter(p => p.category === 'Saloon Grooming');

  // Fake orders data
  const [orders, setOrders] = useState([
    { id: 'ORD-3921', customer: 'John Smith', items: 3, total: 1349, status: 'Delivered', date: 'Today' },
    { id: 'ORD-3920', customer: 'Sarah Lee', items: 1, total: 349, status: 'Shipped', date: 'Today' },
    { id: 'ORD-3919', customer: 'Michael Chen', items: 5, total: 892, status: 'Processing', date: 'Yesterday' },
    { id: 'ORD-3918', customer: 'Emma Wilson', items: 2, total: 269, status: 'Delivered', date: 'Yesterday' },
    { id: 'ORD-3917', customer: 'James Brown', items: 1, total: 1199, status: 'Shipped', date: '2 days ago' },
  ]);

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const filteredTrimmers = saloonProducts.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const totalRevenue = products.reduce((sum, p) => sum + p.price * (Math.floor(p.reviews / 100) + 5), 0);
  const totalProducts = products.length;
  const totalOrders = orders.length + 124;

  // Categories for filter
  const categories = ['All', ...Array.from(new Set(products.map(p => p.category)))];

  const updateProduct = (updatedProduct: Product) => {
    setProducts(products.map(p => p.id === updatedProduct.id ? updatedProduct : p));
    setEditingProduct(null);
  };

  const deleteProduct = (id: number) => {
    if (confirm('Delete this product?')) {
      setProducts(products.filter(p => p.id !== id));
    }
  };

  const addNewProduct = () => {
    if (!newProduct.name || !newProduct.price) {
      alert('Please fill in name and price');
      return;
    }

    const productToAdd: Product = {
      id: Math.max(0, ...products.map(p => p.id)) + 1,
      name: newProduct.name,
      price: newProduct.price,
      originalPrice: newProduct.price + 20,
      image: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?w=500&h=500&fit=crop',
      category: newProduct.category || 'Saloon Grooming',
      rating: 4.7,
      reviews: 340,
      description: newProduct.description || 'Premium grooming tool.',
      inStock: newProduct.inStock ?? true,
      badges: ['New'],
      seller: 'MegaMart Pro',
      delivery: 'Free delivery by Tomorrow',
    };

    setProducts([...products, productToAdd]);
    setNewProduct({ name: '', price: 0, category: 'Saloon Grooming', description: '', inStock: true });
    setShowAddModal(false);
  };

  const updateOrderStatus = (orderId: string, newStatus: string) => {
    setOrders(orders.map(order => 
      order.id === orderId ? { ...order, status: newStatus } : order
    ));
  };

  const renderDashboard = () => (
    <div className="space-y-8">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { icon: DollarSign, label: 'Total Revenue', value: `$${totalRevenue.toLocaleString()}`, change: '+18%', color: 'from-emerald-500 to-teal-600' },
          { icon: PackageCheck, label: 'Total Products', value: totalProducts, change: '+50 trimmers', color: 'from-violet-500 to-purple-600' },
          { icon: ShoppingCart, label: 'Orders This Month', value: totalOrders, change: '+32%', color: 'from-blue-500 to-indigo-600' },
          { icon: UserCheck, label: 'Active Customers', value: '12,847', change: '+9%', color: 'from-orange-500 to-amber-600' },
        ].map((stat, idx) => (
          <div key={idx} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center mb-4`}>
              <stat.icon className="text-white" size={24} />
            </div>
            <div className="text-3xl font-bold text-gray-900 mb-1">{stat.value}</div>
            <div className="flex items-center justify-between">
              <p className="text-gray-500 text-sm">{stat.label}</p>
              <span className="text-emerald-600 text-xs font-semibold flex items-center gap-1">
                {stat.change} <ArrowUp size={12} />
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Insights + Recent Orders */}
      <div className="grid lg:grid-cols-5 gap-6">
        {/* Highlights */}
        <div className="lg:col-span-3 bg-white rounded-2xl p-6 border border-gray-100">
          <h3 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <TrendingUp size={18} /> Key Highlights
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-xl">
              <div>
                <p className="font-medium">Saloon Grooming Trimmers</p>
                <p className="text-sm text-gray-500">{saloonProducts.length} products • {saloonProducts.filter(p => p.inStock).length} in stock</p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-violet-600">{saloonProducts.length}</div>
                <div className="text-xs text-gray-500">NEWEST CATEGORY</div>
              </div>
            </div>
            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-xl">
              <div>
                <p className="font-medium">Best Selling Category</p>
                <p className="text-sm text-gray-500">Electronics • 4,821 units</p>
              </div>
              <div className="text-xl font-bold text-emerald-600">42%</div>
            </div>
            <div className="flex justify-between items-center p-4 bg-gray-50 rounded-xl">
              <div>
                <p className="font-medium">Average Order Value</p>
                <p className="text-sm text-gray-500">Across all categories</p>
              </div>
              <div className="text-2xl font-bold">$284</div>
            </div>
          </div>
        </div>

        {/* Recent Orders */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-gray-100">
          <h3 className="font-semibold text-gray-900 mb-4">Recent Orders</h3>
          <div className="space-y-3">
            {orders.slice(0, 4).map(order => (
              <div key={order.id} className="flex justify-between items-center text-sm border-b pb-3 last:border-none">
                <div>
                  <div className="font-medium">{order.customer}</div>
                  <div className="text-gray-500 text-xs">{order.id} • {order.date}</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">${order.total}</div>
                  <div className={`text-xs ${order.status === 'Delivered' ? 'text-emerald-600' : 'text-amber-500'}`}>{order.status}</div>
                </div>
              </div>
            ))}
          </div>
          <button onClick={() => setActiveTab('orders')} className="mt-4 text-sm text-violet-600 font-medium flex items-center gap-1">
            View all orders →
          </button>
        </div>
      </div>
    </div>
  );

  const renderProductsTable = (filtered: Product[], title: string, showAdd = true) => (
    <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
      <div className="p-6 border-b flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-semibold">{title}</h3>
          <p className="text-sm text-gray-500">{filtered.length} products shown</p>
        </div>
        <div className="flex items-center gap-3">
          {showAdd && (
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition"
            >
              <Plus size={18} /> Add New Product
            </button>
          )}
          <div className="relative">
            <input
              type="text"
              placeholder="Search products..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-4 py-2 border border-gray-200 rounded-xl text-sm w-64 focus:outline-none focus:border-violet-400"
            />
            <Search className="absolute left-3 top-2.5 text-gray-400" size={16} />
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Product</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Category</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Price</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Stock</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Rating</th>
              <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {filtered.map((product) => (
              <tr key={product.id} className="hover:bg-gray-50 transition">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-4">
                    <img src={product.image} alt="" className="w-12 h-12 object-cover rounded-lg border" />
                    <div>
                      <div className="font-medium text-gray-900 line-clamp-1 max-w-[260px]">{product.name}</div>
                      <div className="text-xs text-gray-500">{product.seller}</div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="inline-block px-3 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-700">{product.category}</span>
                </td>
                <td className="px-6 py-4 font-semibold text-gray-900">
                  ${product.price}
                  {product.originalPrice && <span className="text-xs text-gray-400 ml-1 line-through">${product.originalPrice}</span>}
                </td>
                <td className="px-6 py-4">
                  <span className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full ${product.inStock ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-600'}`}>
                    {product.inStock ? 'In Stock' : 'Out of Stock'}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-1 text-sm">
                    <Star className="fill-yellow-400 text-yellow-400" size={14} />
                    {product.rating} <span className="text-gray-400">({product.reviews})</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button
                      onClick={() => setEditingProduct(product)}
                      className="p-2 hover:bg-gray-100 text-violet-600 rounded-lg"
                      title="Edit"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button
                      onClick={() => deleteProduct(product.id)}
                      className="p-2 hover:bg-red-50 text-red-500 rounded-lg"
                      title="Delete"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderOrders = () => (
    <div className="bg-white rounded-2xl border border-gray-100 overflow-hidden">
      <div className="p-6 border-b">
        <h3 className="text-xl font-semibold">Orders Management</h3>
        <p className="text-sm text-gray-500">Manage order fulfillment and status updates</p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Order ID</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Customer</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Items</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Total</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Date</th>
              <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {orders.map(order => (
              <tr key={order.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 font-mono text-sm font-medium">{order.id}</td>
                <td className="px-6 py-4">{order.customer}</td>
                <td className="px-6 py-4">{order.items} items</td>
                <td className="px-6 py-4 font-semibold">${order.total}</td>
                <td className="px-6 py-4 text-sm text-gray-500">{order.date}</td>
                <td className="px-6 py-4">
                  <select
                    value={order.status}
                    onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                    className="border border-gray-300 rounded-lg px-3 py-1 text-sm focus:border-violet-500"
                  >
                    <option value="Processing">Processing</option>
                    <option value="Shipped">Shipped</option>
                    <option value="Delivered">Delivered</option>
                    <option value="Cancelled">Cancelled</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderAnalytics = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-7 rounded-2xl border">
          <h3 className="font-semibold mb-5">Sales by Category</h3>
          {[
            { name: 'Saloon Grooming', value: 32, color: 'bg-zinc-800' },
            { name: 'Electronics', value: 41, color: 'bg-violet-600' },
            { name: 'Fashion', value: 15, color: 'bg-pink-500' },
            { name: 'Home & Living', value: 12, color: 'bg-emerald-500' },
          ].map((cat, i) => (
            <div key={i} className="mb-4">
              <div className="flex justify-between text-sm mb-1">
                <span>{cat.name}</span>
                <span className="font-semibold">{cat.value}%</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full">
                <div className={`h-2 ${cat.color} rounded-full`} style={{ width: `${cat.value}%` }} />
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white p-7 rounded-2xl border">
          <h3 className="font-semibold mb-5">Trimmers Performance</h3>
          <div className="space-y-6">
            <div>
              <div className="flex justify-between mb-2 text-sm">
                <span>Total Trimmers Sold</span>
                <span className="font-bold">{saloonProducts.reduce((s, p) => s + Math.floor(p.reviews / 60), 0)}</span>
              </div>
              <div className="text-4xl font-bold text-zinc-900">18,239</div>
            </div>
            <div className="pt-4 border-t">
              <div className="flex justify-between text-sm mb-2">
                <span>Average Rating</span>
                <span className="font-semibold">4.8</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 h-3 bg-gray-100 rounded">
                  <div className="h-3 bg-yellow-400 rounded w-[96%]" />
                </div>
                <span className="text-sm font-medium">96%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Top Admin Bar */}
      <div className="bg-zinc-900 text-white border-b border-zinc-800 px-6 py-4 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-white/10 rounded-lg flex items-center justify-center">
            <Scissors size={19} />
          </div>
          <div>
            <div className="font-bold tracking-tight">MegaMart Admin</div>
            <div className="text-[10px] text-white/50 -mt-1">CONTROL PANEL</div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-sm hidden sm:block text-white/70">
            Logged in as <span className="text-white font-medium">admin@megamart.com</span>
          </div>
          <button 
            onClick={onLogout} 
            className="flex items-center gap-2 text-sm px-4 py-2 hover:bg-white/10 rounded-xl transition"
          >
            <LogOut size={16} /> Logout
          </button>
        </div>
      </div>

      <div className="flex flex-1">
        {/* Sidebar */}
        <div className="w-60 bg-white border-r border-gray-200 p-5 hidden lg:block">
          <div className="space-y-1">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
              { id: 'products', label: 'All Products', icon: Package },
              { id: 'trimmers', label: 'Saloon Trimmers', icon: Scissors },
              { id: 'orders', label: 'Orders', icon: ShoppingCart },
              { id: 'analytics', label: 'Analytics', icon: BarChart3 },
            ].map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`w-full flex items-center gap-3 px-4 py-3 text-sm rounded-xl transition font-medium ${activeTab === tab.id ? 'bg-violet-100 text-violet-700' : 'hover:bg-gray-50 text-gray-600'}`}
                >
                  <Icon size={18} /> {tab.label}
                </button>
              );
            })}
          </div>

          <div className="mt-8 pt-6 border-t">
            <button className="w-full flex items-center gap-3 px-4 py-3 text-sm rounded-xl text-gray-600 hover:bg-gray-50">
              <Settings size={18} /> Settings
            </button>
            <button onClick={onLogout} className="w-full flex items-center gap-3 px-4 py-3 text-sm rounded-xl text-red-500 hover:bg-red-50 mt-1">
              <LogOut size={18} /> Sign Out
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-6 lg:p-8 overflow-auto">
          <div className="max-w-[1400px]">
            {/* Header */}
            <div className="mb-8 flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 capitalize">{activeTab}</h1>
                <p className="text-gray-500 mt-1 text-sm">Manage your MegaMart store</p>
              </div>
              {activeTab === 'trimmers' && (
                <div className="text-right text-sm">
                  <div className="font-semibold text-violet-700">{saloonProducts.length} Trimmers</div>
                  <div className="text-xs text-gray-500">{saloonProducts.filter(p => p.inStock).length} available</div>
                </div>
              )}
            </div>

            {/* Content */}
            {activeTab === 'dashboard' && renderDashboard()}
            {activeTab === 'products' && renderProductsTable(filteredProducts, 'All Products')}
            {activeTab === 'trimmers' && (
              <>
                <div className="mb-4 flex items-center gap-3">
                  <div className="bg-zinc-900 text-white text-xs tracking-widest px-3 py-1.5 rounded-full font-medium flex items-center gap-2">
                    <Scissors size={14} /> SALOON GROOMING COLLECTION
                  </div>
                  <div className="text-sm text-gray-500">{saloonProducts.length} total models</div>
                </div>
                {renderProductsTable(filteredTrimmers, 'Saloon Beard & Hair Trimmers', true)}
              </>
            )}
            {activeTab === 'orders' && renderOrders()}
            {activeTab === 'analytics' && renderAnalytics()}
          </div>
        </div>
      </div>

      {/* Edit Product Modal */}
      {editingProduct && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-7">
            <div className="flex justify-between items-center mb-5">
              <h3 className="font-semibold text-xl">Edit Product</h3>
              <button onClick={() => setEditingProduct(null)}><X /></button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-medium text-gray-500">PRODUCT NAME</label>
                <input type="text" value={editingProduct.name} onChange={e => setEditingProduct({ ...editingProduct, name: e.target.value })} className="w-full mt-1 border px-4 py-2.5 rounded-xl" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-medium text-gray-500">PRICE</label>
                  <input type="number" value={editingProduct.price} onChange={e => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })} className="w-full mt-1 border px-4 py-2.5 rounded-xl" />
                </div>
                <div>
                  <label className="text-xs font-medium text-gray-500">STOCK STATUS</label>
                  <select value={editingProduct.inStock ? 'true' : 'false'} onChange={e => setEditingProduct({ ...editingProduct, inStock: e.target.value === 'true' })} className="w-full mt-1 border px-4 py-3 rounded-xl">
                    <option value="true">In Stock</option>
                    <option value="false">Out of Stock</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button onClick={() => setEditingProduct(null)} className="flex-1 py-3 border rounded-xl">Cancel</button>
              <button onClick={() => updateProduct(editingProduct)} className="flex-1 py-3 bg-violet-600 text-white rounded-xl font-semibold">Save Changes</button>
            </div>
          </div>
        </div>
      )}

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
          <div className="bg-white w-full max-w-md rounded-3xl p-7">
            <div className="flex justify-between mb-5">
              <h3 className="font-semibold text-xl">Add New Product</h3>
              <button onClick={() => setShowAddModal(false)}><X size={20} /></button>
            </div>

            <div className="space-y-4">
              <input 
                placeholder="Product name" 
                value={newProduct.name} 
                onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })} 
                className="w-full border px-4 py-3 rounded-xl" 
              />
              <div className="grid grid-cols-2 gap-4">
                <input 
                  type="number" 
                  placeholder="Price" 
                  value={newProduct.price} 
                  onChange={(e) => setNewProduct({ ...newProduct, price: Number(e.target.value) })} 
                  className="border px-4 py-3 rounded-xl" 
                />
                <select 
                  value={newProduct.category} 
                  onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })} 
                  className="border px-4 py-3 rounded-xl"
                >
                  {categories.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <textarea 
                placeholder="Short description..." 
                value={newProduct.description} 
                onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })} 
                className="w-full border px-4 py-3 rounded-xl h-24 resize-none" 
              />
            </div>

            <div className="mt-6 flex gap-3">
              <button onClick={() => setShowAddModal(false)} className="flex-1 py-3 border rounded-xl">Cancel</button>
              <button onClick={addNewProduct} className="flex-1 py-3 bg-zinc-900 text-white rounded-xl font-semibold">Add Product</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
