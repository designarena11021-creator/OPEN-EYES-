import { useState } from 'react';
import { Lock, Mail, Eye, EyeOff, ArrowLeft, Shield } from 'lucide-react';

interface AdminLoginProps {
  onLogin: () => void;
  onBack: () => void;
}

export default function AdminLogin({ onLogin, onBack }: AdminLoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      if (email === 'admin@megamart.com' && password === 'admin123') {
        onLogin();
      } else {
        setError('Invalid credentials. Use admin@megamart.com / admin123');
      }
      setIsLoading(false);
    }, 700);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-950 via-gray-900 to-black flex items-center justify-center p-4">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-10 w-72 h-72 bg-violet-500 rounded-full blur-[120px]" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-indigo-500 rounded-full blur-[120px]" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Back to Shop */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-white/70 hover:text-white mb-8 transition-colors"
        >
          <ArrowLeft size={18} />
          <span>Back to MegaMart Store</span>
        </button>

        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-zinc-900 to-black p-8 text-center text-white">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center backdrop-blur-sm">
                <Shield className="w-9 h-9" />
              </div>
            </div>
            <h1 className="text-3xl font-bold tracking-tight">MegaMart Admin</h1>
            <p className="text-white/60 mt-1 text-sm">Secure Admin Portal</p>
          </div>

          <div className="p-8">
            <div className="mb-6">
              <h2 className="text-2xl font-semibold text-gray-900">Welcome back</h2>
              <p className="text-gray-500 text-sm mt-1">Sign in to access the admin dashboard</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="admin@megamart.com"
                    className="w-full pl-11 pr-4 py-3.5 border border-gray-200 rounded-xl focus:border-violet-500 focus:ring-1 focus:ring-violet-500 outline-none transition text-sm"
                    required
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full pl-11 pr-12 py-3.5 border border-gray-200 rounded-xl focus:border-violet-500 focus:ring-1 focus:ring-violet-500 outline-none transition text-sm"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>

              {/* Error Message */}
              {error && (
                <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-xl text-sm">
                  {error}
                </div>
              )}

              {/* Options */}
              <div className="flex items-center justify-between text-sm">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" className="w-4 h-4 accent-violet-600" />
                  <span className="text-gray-600">Remember me</span>
                </label>
                <button type="button" className="text-violet-600 hover:underline font-medium">
                  Forgot password?
                </button>
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full bg-black hover:bg-zinc-800 disabled:bg-zinc-300 transition-colors text-white py-4 rounded-xl font-semibold flex items-center justify-center gap-2 text-sm tracking-wide"
              >
                {isLoading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    SIGNING IN...
                  </>
                ) : (
                  'SIGN IN TO ADMIN PANEL'
                )}
              </button>
            </form>

            {/* Demo Credentials */}
            <div className="mt-6 p-4 bg-violet-50 border border-violet-100 rounded-xl text-xs">
              <p className="font-semibold text-violet-700 mb-1">Demo Credentials</p>
              <p className="text-violet-600">Email: admin@megamart.com</p>
              <p className="text-violet-600">Password: admin123</p>
            </div>
          </div>

          <div className="border-t bg-gray-50 px-8 py-4 text-center">
            <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
              <Shield size={14} /> Secured with enterprise-grade encryption
            </div>
          </div>
        </div>

        <p className="text-center text-white/40 text-xs mt-6">
          This is a secure area. Unauthorized access is prohibited.
        </p>
      </div>
    </div>
  );
}
