import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Search, ShoppingCart, User, Menu, X, Heart, Star, Truck, Shield,
  ArrowRight, Plus, Minus,
  Check, CreditCard, Package, Clock, Filter,
  Award, Zap, Globe, Mail, Phone,
  ChevronDown, Percent, Gift, RotateCcw, Headphones, Scissors, Settings
} from 'lucide-react';
import { categories, products as initialProducts, heroSlides, deals } from './data';
import { Product, CartItem } from './types';
import AdminLogin from './components/AdminLogin';
import AdminDashboard from './components/AdminDashboard';

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [currentSlide, setCurrentSlide] = useState(0);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [sortBy, setSortBy] = useState('featured');

  // Admin Panel States
  const [currentView, setCurrentView] = useState<'shop' | 'admin-login' | 'admin-dashboard'>('shop');
  const [adminProducts, setAdminProducts] = useState<Product[]>(initialProducts);

  // Auto-rotate hero slides
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const addToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const removeFromCart = (productId: number) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const updateQuantity = (productId: number, delta: number) => {
    setCart((prev) =>
      prev.map((item) => {
        if (item.product.id === productId) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : item;
        }
        return item;
      }).filter((item) => item.quantity > 0)
    );
  };

  const toggleWishlist = (productId: number) => {
    setWishlist((prev) =>
      prev.includes(productId)
        ? prev.filter((id) => id !== productId)
        : [...prev, productId]
    );
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const filteredProducts = adminProducts.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case 'price-low': return a.price - b.price;
      case 'price-high': return b.price - a.price;
      case 'rating': return b.rating - a.rating;
      default: return 0;
    }
  });

  const saloonTrimmers = adminProducts.filter((product) => product.category === 'Saloon Grooming');
  const featuredSaloonTrimmers = saloonTrimmers.slice(0, 4);

  const handleAdminLogin = () => setCurrentView('admin-dashboard');
  const handleBackToShop = () => setCurrentView('shop');
  const handleAdminLogout = () => setCurrentView('shop');

  return (
    <>
      {currentView === 'admin-login' && (
        <AdminLogin onLogin={handleAdminLogin} onBack={handleBackToShop} />
      )}

      {currentView === 'admin-dashboard' && (
        <AdminDashboard 
          products={adminProducts} 
          setProducts={setAdminProducts} 
          onLogout={handleAdminLogout} 
        />
      )}

      {currentView === 'shop' && (
        <div className="min-h-screen bg-gray-50">
      {/* Top Bar */}
      <div className="bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1"><Globe size={14} /> English / USD</span>
            <span className="hidden sm:flex items-center gap-1"><Phone size={14} /> 1-800-MEGAMART</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1"><Truck size={14} /> Free shipping on orders $50+</span>
            <span className="hidden md:flex items-center gap-1"><RotateCcw size={14} /> 30-day returns</span>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <motion.div 
              className="flex items-center gap-2 cursor-pointer"
              whileHover={{ scale: 1.05 }}
            >
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center">
                <ShoppingCart className="text-white" size={24} />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-indigo-600 bg-clip-text text-transparent">
                  MegaMart
                </h1>
                <p className="text-xs text-gray-500">Better than the rest</p>
              </div>
            </motion.div>

            {/* Search Bar */}
            <div className="hidden lg:flex flex-1 max-w-2xl mx-8">
              <div className="relative w-full">
                <input
                  type="text"
                  placeholder="Search millions of products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-3 rounded-full border-2 border-gray-200 focus:border-violet-500 focus:outline-none transition-colors"
                />
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                <button className="absolute right-2 top-1/2 -translate-y-1/2 bg-gradient-to-r from-violet-600 to-indigo-600 text-white px-6 py-2 rounded-full hover:shadow-lg transition-shadow">
                  Search
                </button>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-4">
              <motion.button
                className="hidden md:flex items-center gap-2 text-gray-600 hover:text-violet-600 transition-colors"
                whileHover={{ scale: 1.05 }}
              >
                <Heart size={22} />
                <span className="text-sm font-medium">Wishlist</span>
                {wishlist.length > 0 && (
                  <span className="bg-pink-500 text-white text-xs px-2 py-0.5 rounded-full">
                    {wishlist.length}
                  </span>
                )}
              </motion.button>

              <motion.button
                className="hidden md:flex items-center gap-2 text-gray-600 hover:text-violet-600 transition-colors"
                whileHover={{ scale: 1.05 }}
              >
                <User size={22} />
                <span className="text-sm font-medium">Account</span>
              </motion.button>

              <button
                onClick={() => setCurrentView('admin-login')}
                className="hidden md:flex items-center gap-2 px-3 py-2 text-xs font-semibold bg-zinc-900 hover:bg-black transition-colors text-white rounded-full"
              >
                <Settings size={16} /> ADMIN
              </button>

              <motion.button
                className="relative flex items-center gap-2 bg-gradient-to-r from-violet-600 to-indigo-600 text-white px-4 py-2.5 rounded-full hover:shadow-lg transition-shadow"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setIsCartOpen(true)}
              >
                <ShoppingCart size={22} />
                <span className="hidden sm:inline text-sm font-medium">Cart</span>
                {cartCount > 0 && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-6 h-6 rounded-full flex items-center justify-center font-bold"
                  >
                    {cartCount}
                  </motion.span>
                )}
              </motion.button>

              <button
                className="lg:hidden p-2"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Search */}
          <div className="lg:hidden pb-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-full border-2 border-gray-200 focus:border-violet-500 focus:outline-none"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="lg:hidden border-t bg-white overflow-hidden"
            >
              <div className="container mx-auto px-4 py-4 space-y-4">
                <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 cursor-pointer">
                  <User size={20} className="text-violet-600" />
                  <span>My Account</span>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 cursor-pointer">
                  <Heart size={20} className="text-pink-600" />
                  <span>Wishlist ({wishlist.length})</span>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 cursor-pointer">
                  <Package size={20} className="text-blue-600" />
                  <span>My Orders</span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.5 }}
            className={`bg-gradient-to-r ${heroSlides[currentSlide].gradient} py-16 md:py-24`}
          >
            <div className="container mx-auto px-4">
              <div className="grid md:grid-cols-2 gap-8 items-center">
                <div className="text-white space-y-6">
                  <motion.span
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="inline-block bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full text-sm font-medium"
                  >
                    🎉 {heroSlides[currentSlide].subtitle}
                  </motion.span>
                  <motion.h2
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="text-4xl md:text-6xl font-bold"
                  >
                    {heroSlides[currentSlide].title}
                  </motion.h2>
                  <motion.p
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 }}
                    className="text-lg md:text-xl text-white/90"
                  >
                    {heroSlides[currentSlide].description}
                  </motion.p>
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5 }}
                    className="flex flex-wrap gap-4"
                  >
                    <button className="bg-white text-violet-600 px-8 py-4 rounded-full font-semibold hover:shadow-xl transition-shadow flex items-center gap-2">
                      Shop Now <ArrowRight size={20} />
                    </button>
                    <button className="border-2 border-white text-white px-8 py-4 rounded-full font-semibold hover:bg-white/10 transition-colors">
                      View Deals
                    </button>
                  </motion.div>
                </div>
                <div className="hidden md:block">
                  <motion.img
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.3 }}
                    src={heroSlides[currentSlide].image}
                    alt={heroSlides[currentSlide].title}
                    className="rounded-3xl shadow-2xl w-full max-w-md mx-auto"
                  />
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Slide Controls */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2">
          {heroSlides.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlide ? 'bg-white w-8' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </section>

      {/* Quick Deals */}
      <section className="py-8 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {deals.map((deal) => (
              <motion.div
                key={deal.id}
                whileHover={{ scale: 1.02 }}
                className={`bg-gradient-to-r ${deal.color} rounded-2xl p-6 text-white cursor-pointer`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-bold">{deal.title}</h3>
                    <p className="text-3xl font-bold mt-1">{deal.discount}</p>
                  </div>
                  <div className="text-right">
                    <Clock size={32} className="mx-auto mb-2" />
                    <p className="text-sm opacity-90">{deal.timeLeft}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Shop by Category</h2>
            <button className="text-violet-600 font-medium flex items-center gap-2 hover:gap-3 transition-all">
              View All <ArrowRight size={18} />
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-4">
            {categories.map((category) => (
              <motion.button
                key={category.id}
                whileHover={{ scale: 1.05, y: -5 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(
                  selectedCategory === category.name ? 'All' : category.name
                )}
                className={`p-6 rounded-2xl bg-white shadow-md hover:shadow-xl transition-shadow text-center ${
                  selectedCategory === category.name ? 'ring-2 ring-violet-500' : ''
                }`}
              >
                <div className={`w-14 h-14 mx-auto rounded-full bg-gradient-to-br ${category.color} flex items-center justify-center text-2xl mb-3`}>
                  {category.icon}
                </div>
                <p className="font-medium text-gray-700 text-sm">{category.name}</p>
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* Saloon Beard & Hair Trimmers */}
      <section className="bg-white py-14">
        <div className="container mx-auto px-4">
          <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div className="max-w-2xl">
              <div className="mb-3 flex items-center gap-3 text-sm font-semibold uppercase tracking-[0.25em] text-violet-600">
                <Scissors size={18} />
                New saloon collection
              </div>
              <h2 className="text-3xl font-bold text-gray-950 md:text-4xl">50 Saloon Beard & Hair Trimmers</h2>
              <p className="mt-3 text-gray-500">
                Professional cordless machines for clean fades, sharp beard lines, neck trims, and home grooming.
              </p>
            </div>
            <a
              href="#products"
              onClick={() => setSelectedCategory('Saloon Grooming')}
              className="inline-flex items-center gap-2 rounded-full bg-gray-950 px-6 py-3 font-semibold text-white transition hover:bg-violet-700"
            >
              Shop all 50 <ArrowRight size={18} />
            </a>
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {featuredSaloonTrimmers.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.08 }}
                whileHover={{ y: -6 }}
                className="overflow-hidden rounded-2xl border border-gray-100 bg-gray-50"
              >
                <button className="block w-full" onClick={() => setSelectedProduct(product)}>
                  <img src={product.image} alt={product.name} className="aspect-[4/3] w-full object-cover" />
                </button>
                <div className="p-5">
                  <div className="mb-2 flex items-center justify-between gap-3">
                    <span className="rounded-full bg-violet-100 px-3 py-1 text-xs font-bold text-violet-700">
                      {product.badges?.[0]}
                    </span>
                    <span className="flex items-center gap-1 text-sm font-semibold text-gray-700">
                      <Star size={15} className="fill-yellow-400 text-yellow-400" /> {product.rating}
                    </span>
                  </div>
                  <h3 className="line-clamp-2 font-bold text-gray-950">{product.name}</h3>
                  <p className="mt-2 line-clamp-2 text-sm text-gray-500">{product.description}</p>
                  <div className="mt-4 flex items-center justify-between">
                    <div>
                      <p className="text-xl font-black text-gray-950">${product.price}</p>
                      <p className="text-xs text-green-600">{product.delivery}</p>
                    </div>
                    <button
                      onClick={() => addToCart(product)}
                      disabled={!product.inStock}
                      className="rounded-full bg-violet-600 px-4 py-2 text-sm font-bold text-white transition hover:bg-violet-700 disabled:bg-gray-300"
                    >
                      Add
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Banner */}
      <section className="py-8 bg-white border-y">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: Truck, title: 'Free Shipping', desc: 'On orders over $50' },
              { icon: Shield, title: 'Secure Payment', desc: '100% secure transactions' },
              { icon: RotateCcw, title: 'Easy Returns', desc: '30-day return policy' },
              { icon: Headphones, title: '24/7 Support', desc: 'Dedicated support team' },
            ].map((feature, index) => (
              <motion.div
                key={index}
                className="flex items-center gap-4"
                whileHover={{ x: 5 }}
              >
                <div className="w-12 h-12 rounded-full bg-violet-100 flex items-center justify-center">
                  <feature.icon className="text-violet-600" size={24} />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">{feature.title}</h4>
                  <p className="text-sm text-gray-500">{feature.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
            <div>
              <h2 className="text-3xl font-bold text-gray-900">
                {selectedCategory === 'All' ? 'Featured Products' : selectedCategory}
              </h2>
              <p className="text-gray-500 mt-1">{sortedProducts.length} products found</p>
            </div>
            <div className="flex items-center gap-4">
              <button className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-50">
                <Filter size={18} />
                <span>Filter</span>
              </button>
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="appearance-none px-4 py-2 border rounded-lg pr-10 cursor-pointer hover:bg-gray-50"
                >
                  <option value="featured">Featured</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="rating">Top Rated</option>
                </select>
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {sortedProducts.map((product) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                whileHover={{ y: -8 }}
                className="bg-white rounded-2xl shadow-md hover:shadow-xl transition-all overflow-hidden group"
              >
                {/* Product Image */}
                <div className="relative aspect-square overflow-hidden bg-gray-100">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  {/* Badges */}
                  <div className="absolute top-3 left-3 flex flex-col gap-1">
                    {product.badges?.map((badge, index) => (
                      <span
                        key={index}
                        className={`px-2 py-1 rounded-full text-xs font-semibold ${
                          badge === 'Best Seller' ? 'bg-yellow-500 text-white' :
                          badge === 'New' ? 'bg-green-500 text-white' :
                          badge === 'Hot Deal' ? 'bg-red-500 text-white' :
                          badge === 'Premium' ? 'bg-purple-500 text-white' :
                          'bg-gray-800 text-white'
                        }`}
                      >
                        {badge}
                      </span>
                    ))}
                  </div>
                  {/* Wishlist Button */}
                  <button
                    onClick={() => toggleWishlist(product.id)}
                    className={`absolute top-3 right-3 w-10 h-10 rounded-full flex items-center justify-center transition-all ${
                      wishlist.includes(product.id)
                        ? 'bg-pink-500 text-white'
                        : 'bg-white/90 text-gray-600 hover:bg-pink-500 hover:text-white'
                    }`}
                  >
                    <Heart size={18} fill={wishlist.includes(product.id) ? 'currentColor' : 'none'} />
                  </button>
                  {/* Quick Actions */}
                  <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => setSelectedProduct(product)}
                      className="w-full bg-white text-gray-900 py-2.5 rounded-full font-medium hover:bg-violet-600 hover:text-white transition-colors"
                    >
                      Quick View
                    </button>
                  </div>
                </div>

                {/* Product Info */}
                <div className="p-4">
                  <p className="text-xs text-violet-600 font-medium mb-1">{product.category}</p>
                  <h3 
                    className="font-semibold text-gray-900 mb-2 line-clamp-2 cursor-pointer hover:text-violet-600"
                    onClick={() => setSelectedProduct(product)}
                  >
                    {product.name}
                  </h3>
                  
                  {/* Rating */}
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          size={14}
                          className={i < Math.floor(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-500">({product.reviews.toLocaleString()})</span>
                  </div>

                  {/* Price */}
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-xl font-bold text-gray-900">${product.price.toLocaleString()}</span>
                    {product.originalPrice && (
                      <span className="text-sm text-gray-400 line-through">${product.originalPrice.toLocaleString()}</span>
                    )}
                    {product.originalPrice && (
                      <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-medium">
                        {Math.round((1 - product.price / product.originalPrice) * 100)}% OFF
                      </span>
                    )}
                  </div>

                  {/* Stock Status */}
                  <div className="flex items-center justify-between mb-4">
                    <span className={`text-sm ${product.inStock ? 'text-green-600' : 'text-red-500'}`}>
                      {product.inStock ? '✓ In Stock' : '✗ Out of Stock'}
                    </span>
                    <span className="text-xs text-gray-500">{product.delivery}</span>
                  </div>

                  {/* Add to Cart */}
                  <button
                    onClick={() => addToCart(product)}
                    disabled={!product.inStock}
                    className={`w-full py-3 rounded-full font-semibold transition-all flex items-center justify-center gap-2 ${
                      product.inStock
                        ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white hover:shadow-lg hover:scale-[1.02]'
                        : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    <ShoppingCart size={18} />
                    {product.inStock ? 'Add to Cart' : 'Out of Stock'}
                  </button>
                </div>
              </motion.div>
            ))}
          </div>

          {sortedProducts.length === 0 && (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search size={40} className="text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No products found</h3>
              <p className="text-gray-500">Try adjusting your search or filter criteria</p>
            </div>
          )}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold mb-4">Why Shop at MegaMart?</h2>
            <p className="text-white/80 text-lg max-w-2xl mx-auto">
              We're committed to providing the best shopping experience with unbeatable prices and service
            </p>
          </div>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: Award, title: 'Best Quality', desc: 'Curated products from top brands worldwide' },
              { icon: Percent, title: 'Best Prices', desc: 'Price match guarantee on all products' },
              { icon: Zap, title: 'Fast Delivery', desc: 'Same-day delivery in select areas' },
              { icon: Gift, title: 'Rewards Program', desc: 'Earn points on every purchase' },
            ].map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-20 h-20 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <item.icon size={40} />
                </div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-white/70">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="bg-gradient-to-r from-gray-900 to-gray-800 rounded-3xl p-8 md:p-12 text-center text-white">
            <div className="max-w-2xl mx-auto">
              <Mail className="w-16 h-16 mx-auto mb-6 text-violet-400" />
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Subscribe to Our Newsletter</h2>
              <p className="text-gray-300 mb-8">
                Get exclusive deals, early access to sales, and 10% off your first order
              </p>
              <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-6 py-4 rounded-full text-gray-900 focus:outline-none focus:ring-2 focus:ring-violet-500"
                />
                <button className="bg-gradient-to-r from-violet-600 to-indigo-600 px-8 py-4 rounded-full font-semibold hover:shadow-lg transition-shadow whitespace-nowrap">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white pt-16 pb-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 mb-12">
            <div className="col-span-2 lg:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-600 to-indigo-600 flex items-center justify-center">
                  <ShoppingCart className="text-white" size={24} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">MegaMart</h3>
                  <p className="text-sm text-gray-400">Better than the rest</p>
                </div>
              </div>
              <p className="text-gray-400 mb-6 max-w-sm">
                Your one-stop destination for everything you need. Quality products, unbeatable prices, and exceptional service.
              </p>
              <div className="flex gap-4">
                {[1, 2, 3, 4].map((_, index) => (
                  <a
                    key={index}
                    href="#"
                    className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-violet-600 transition-colors"
                  >
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
                    </svg>
                  </a>
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">Shop</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">All Categories</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Deals of the Day</a></li>
                <li><a href="#" className="hover:text-white transition-colors">New Arrivals</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Best Sellers</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Track Order</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Returns</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Press</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Blog</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-800 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-gray-400 text-sm">
                © 2026 MegaMart. All rights reserved.
              </p>
              <button
                onClick={() => setCurrentView('admin-login')}
                className="text-xs text-gray-500 hover:text-white underline transition-colors"
              >
                Admin Portal
              </button>
              <div className="flex items-center gap-6">
                <img src="https://img.icons8.com/color/48/visa.png" alt="Visa" className="h-8" />
                <img src="https://img.icons8.com/color/48/mastercard.png" alt="Mastercard" className="h-8" />
                <img src="https://img.icons8.com/color/48/paypal.png" alt="PayPal" className="h-8" />
                <img src="https://img.icons8.com/color/48/apple-pay.png" alt="Apple Pay" className="h-8" />
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Cart Sidebar */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-50"
              onClick={() => setIsCartOpen(false)}
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25 }}
              className="fixed right-0 top-0 h-full w-full max-w-md bg-white z-50 shadow-2xl"
            >
              <div className="flex flex-col h-full">
                <div className="flex items-center justify-between p-6 border-b">
                  <h2 className="text-2xl font-bold flex items-center gap-2">
                    <ShoppingCart size={24} />
                    Your Cart ({cartCount})
                  </h2>
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                  >
                    <X size={24} />
                  </button>
                </div>

                <div className="flex-1 overflow-y-auto p-6">
                  {cart.length === 0 ? (
                    <div className="text-center py-16">
                      <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <ShoppingCart size={40} className="text-gray-400" />
                      </div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">Your cart is empty</h3>
                      <p className="text-gray-500 mb-6">Start shopping to add items to your cart</p>
                      <button
                        onClick={() => setIsCartOpen(false)}
                        className="bg-gradient-to-r from-violet-600 to-indigo-600 text-white px-8 py-3 rounded-full font-semibold"
                      >
                        Continue Shopping
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {cart.map((item) => (
                        <motion.div
                          key={item.product.id}
                          layout
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -20 }}
                          className="flex gap-4 p-4 bg-gray-50 rounded-xl"
                        >
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            className="w-20 h-20 object-cover rounded-lg"
                          />
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900 line-clamp-1">{item.product.name}</h4>
                            <p className="text-sm text-gray-500 mb-2">{item.product.category}</p>
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <button
                                  onClick={() => updateQuantity(item.product.id, -1)}
                                  className="w-8 h-8 rounded-full bg-white border flex items-center justify-center hover:bg-gray-100"
                                >
                                  <Minus size={14} />
                                </button>
                                <span className="w-8 text-center font-medium">{item.quantity}</span>
                                <button
                                  onClick={() => updateQuantity(item.product.id, 1)}
                                  className="w-8 h-8 rounded-full bg-white border flex items-center justify-center hover:bg-gray-100"
                                >
                                  <Plus size={14} />
                                </button>
                              </div>
                              <div className="text-right">
                                <p className="font-bold text-gray-900">
                                  ${(item.product.price * item.quantity).toLocaleString()}
                                </p>
                                <button
                                  onClick={() => removeFromCart(item.product.id)}
                                  className="text-red-500 text-sm hover:underline"
                                >
                                  Remove
                                </button>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </div>

                {cart.length > 0 && (
                  <div className="border-t p-6 space-y-4">
                    <div className="flex items-center justify-between text-gray-600">
                      <span>Subtotal</span>
                      <span>${cartTotal.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between text-gray-600">
                      <span>Shipping</span>
                      <span>{cartTotal >= 50 ? 'Free' : '$9.99'}</span>
                    </div>
                    <div className="flex items-center justify-between text-xl font-bold text-gray-900 pt-4 border-t">
                      <span>Total</span>
                      <span>${(cartTotal + (cartTotal >= 50 ? 0 : 9.99)).toLocaleString()}</span>
                    </div>
                    <button className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 text-white py-4 rounded-full font-semibold hover:shadow-lg transition-shadow flex items-center justify-center gap-2">
                      <CreditCard size={20} />
                      Checkout
                    </button>
                    <p className="text-center text-sm text-gray-500 flex items-center justify-center gap-2">
                      <Shield size={14} />
                      Secure checkout
                    </p>
                  </div>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Product Detail Modal */}
      <AnimatePresence>
        {selectedProduct && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
              onClick={() => setSelectedProduct(null)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
              >
                <div className="grid md:grid-cols-2 gap-8 p-8">
                  <div className="relative">
                    <img
                      src={selectedProduct.image}
                      alt={selectedProduct.name}
                      className="w-full aspect-square object-cover rounded-2xl"
                    />
                    <button
                      onClick={() => setSelectedProduct(null)}
                      className="absolute top-4 right-4 w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-gray-100"
                    >
                      <X size={20} />
                    </button>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      {selectedProduct.badges?.map((badge, index) => (
                        <span
                          key={index}
                          className="px-3 py-1 bg-violet-100 text-violet-700 rounded-full text-sm font-medium"
                        >
                          {badge}
                        </span>
                      ))}
                    </div>
                    <h2 className="text-3xl font-bold text-gray-900 mb-2">{selectedProduct.name}</h2>
                    <div className="flex items-center gap-4 mb-4">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            size={18}
                            className={i < Math.floor(selectedProduct.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}
                          />
                        ))}
                      </div>
                      <span className="text-gray-500">({selectedProduct.reviews.toLocaleString()} reviews)</span>
                    </div>
                    <div className="flex items-center gap-3 mb-6">
                      <span className="text-4xl font-bold text-gray-900">${selectedProduct.price.toLocaleString()}</span>
                      {selectedProduct.originalPrice && (
                        <>
                          <span className="text-xl text-gray-400 line-through">${selectedProduct.originalPrice.toLocaleString()}</span>
                          <span className="bg-red-100 text-red-600 px-3 py-1 rounded-full font-semibold">
                            Save ${(selectedProduct.originalPrice - selectedProduct.price).toLocaleString()}
                          </span>
                        </>
                      )}
                    </div>
                    <p className="text-gray-600 mb-6">{selectedProduct.description}</p>
                    
                    <div className="space-y-3 mb-6">
                      <div className="flex items-center gap-3 text-gray-600">
                        <Check className="text-green-500" size={20} />
                        <span>{selectedProduct.inStock ? 'In Stock' : 'Out of Stock'}</span>
                      </div>
                      <div className="flex items-center gap-3 text-gray-600">
                        <Truck className="text-violet-600" size={20} />
                        <span>{selectedProduct.delivery}</span>
                      </div>
                      <div className="flex items-center gap-3 text-gray-600">
                        <Shield className="text-blue-600" size={20} />
                        <span>2 Year Warranty</span>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <button
                        onClick={() => {
                          addToCart(selectedProduct);
                          setSelectedProduct(null);
                        }}
                        disabled={!selectedProduct.inStock}
                        className={`flex-1 py-4 rounded-full font-semibold transition-all flex items-center justify-center gap-2 ${
                          selectedProduct.inStock
                            ? 'bg-gradient-to-r from-violet-600 to-indigo-600 text-white hover:shadow-lg'
                            : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                        }`}
                      >
                        <ShoppingCart size={20} />
                        Add to Cart
                      </button>
                      <button
                        onClick={() => toggleWishlist(selectedProduct.id)}
                        className={`w-14 h-14 rounded-full border-2 flex items-center justify-center transition-all ${
                          wishlist.includes(selectedProduct.id)
                            ? 'bg-pink-500 border-pink-500 text-white'
                            : 'border-gray-300 hover:border-pink-500 hover:text-pink-500'
                        }`}
                      >
                        <Heart size={24} fill={wishlist.includes(selectedProduct.id) ? 'currentColor' : 'none'} />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
        </div>
      )}
    </>
  );
}
